///<reference types ='cypress' />
import BluebiteLoginPage from "../POM/Test";

describe("BlueBite_LoginUser and SumbitForm Scenario's", () => {
  let Data;
  let pom = new BluebiteLoginPage()


  beforeEach("TestData", () => {
    cy.visit(Cypress.env("baseurl"))
    cy.fixture("TestData").then((data) => {
      Data = data;
    })

  })

  it("Test1_Validate the login Url is lading on the correct page ", () => {

    cy.url().should("eq", Data.URL)
    cy.get(pom.UserInfo.PageTitle).should("have.text",Data.PageName)

  })

  it("Test2_Validate the component attributes and text field of the login page", () => {

    // Name* field validation..

    pom.getNameFeild(Data.Validation_name_field)
    cy.get(pom.UserInfo.LoginName_css).should("be.enabled").and("have.attr", "type", "text")

    //Email* field validation..
    pom.getEmailFeild(Data.Validation_email_field)
    cy.get(pom.UserInfo.LoginEmail_Css).should("be.enabled").and("have.attr", "type", "text")

    //Age* field validation..

    pom.getAgeFeild(Data.Validation_Age_field)
    cy.get(pom.UserInfo.LoginAge_css).should("be.enabled").and("have.attr", "type", "text")

    //Reason field validation..

    pom.getReasonFeild(Data.Validation_reason_field)
    cy.get(pom.UserInfo.LoginReason_css).should("be.enabled").and("have.attr", "type", "text")

    //button component validation..
    cy.get('[type="button"]').should("be.enabled")

  })


  it("Test3_Verify that the form is successfully submitted when all required fields are filled correctly", () => {

    //Custom Commands to fill the form and submit with correct data..
    cy.Fillout_Form_and_submit(pom.UserInfo.LoginName_css, pom.UserInfo.LoginEmail_Css,
      pom.UserInfo.LoginAge_css, pom.UserInfo.LoginReason_css, Data.name, Data.Correct_email, Data.Correct_Age, Data.Reason)
    cy.get('.snippet__Body-sc-12bo3rm-0.cmpVnN').eq(1).should("include.text", "Submission Confirmed")

  })

  it("Test4_Verify that the form is not submitted if the user is under 18", () => {

    cy.Fillout_Form_and_submit(pom.UserInfo.LoginName_css, pom.UserInfo.LoginEmail_Css,
      pom.UserInfo.LoginAge_css, pom.UserInfo.LoginReason_css, Data.name, Data.Correct_email, Data.Below_Age, Data.Reason)
    cy.get('.snippet__Body-sc-12bo3rm-0.cmpVnN').eq(1).should("have.text", "Must be 18 or older to enter.")

  })

  it("Test5_Verify that the form is not submitted if any required fields are missing", () => {

    //Custom Commands to fill the form and submit without Email data..
    cy.Fillout_Form_and_submit_WthoutEmail(pom.UserInfo.LoginName_css,
      pom.UserInfo.LoginAge_css, pom.UserInfo.LoginReason_css, Data.name, Data.Correct_Age, Data.Reason)
    cy.get('.snippet__Body-sc-12bo3rm-0.cmpVnN').eq(1).should("not.contain.text", "Submission Confirmed")

  })

  it("Test6_Verify that the form is not submitted if the email address is invalid", () => {

    cy.Fillout_Form_and_submit(pom.UserInfo.LoginName_css, pom.UserInfo.LoginEmail_Css,
      pom.UserInfo.LoginAge_css, pom.UserInfo.LoginReason_css, Data.name, Data.Wrong_email, Data.Correct_Age, Data.Reason)
    cy.get('.snippet__Body-sc-12bo3rm-0.cmpVnN').eq(1).should("not.contain.text", "Submission Confirmed")

  })

  it("Test7_Verify that the user can submit the form multiple times", () => {

    let count = 0;

    cy.Fillout_Form_and_submit(pom.UserInfo.LoginName_css, pom.UserInfo.LoginEmail_Css,
      pom.UserInfo.LoginAge_css, pom.UserInfo.LoginReason_css, Data.name, Data.Correct_email, Data.Correct_Age, Data.Reason)
    cy.get('.snippet__Body-sc-12bo3rm-0.cmpVnN').eq(1).should("include.text", "Submission Confirmed")
    count++


    cy.visit(Cypress.env("baseurl"))
    cy.Fillout_Form_and_submit(pom.UserInfo.LoginName_css, pom.UserInfo.LoginEmail_Css,
      pom.UserInfo.LoginAge_css, pom.UserInfo.LoginReason_css, Data.name, Data.Correct_email, Data.Correct_Age, Data.Reason)
    cy.get('.snippet__Body-sc-12bo3rm-0.cmpVnN').eq(1).should("include.text", "Submission Confirmed")
    count++

    cy.log("The number of times the same user created the form: " + count)

  })

  it("Test8_Verify that the input field turns blue when focused", () => {


    cy.get(pom.UserInfo.LoginName_css).trigger("focus").should("have.css", "color", "rgb(0,0,255)")

  })

  it("Test9_Verify that required fields turn red if form submission fails due to missing information", () => {
    cy.get('[type="button"]').click();
  
    let hasFailures = false;
  
    const checkCssColor = (selector, expectedColor) => {
      cy.get(selector).then($el => {
        const color = $el.css('color')
        if (color !== expectedColor) {
          hasFailures = true;
          console.error(`${selector} - expected color: ${expectedColor}, but got: ${color}`)
        }

        try {
          expect(color).to.equal(expectedColor)
        } catch (error) {
          console.error(error)
        }
      });
    };

    checkCssColor(pom.UserInfo.LoginName_css, "rgb(255, 0, 0)")
    checkCssColor(pom.UserInfo.LoginAge_css, "rgb(255, 0, 0)")
    checkCssColor(pom.UserInfo.LoginEmail_Css, "rgb(255, 0, 0)")

    cy.then(() => {
      if (hasFailures) {
        throw new Error("One or more color checks failed.")
      }
    })
  })

})




// https://on.cypress.io/custom-commands
// ***********************************************

Cypress.Commands.add("Fillout_Form_and_submit",(nameCss,emailCss,ageCss,reasonCss,nameData,emailData,ageData,reasonData)=>{

    cy.get(nameCss).type(nameData)
    cy.get(emailCss).type(emailData)
    cy.get(ageCss).type(ageData)
    cy.get(reasonCss).type(reasonData)
    cy.get('[type="button"]').click()
})

Cypress.Commands.add("Fillout_Form_and_submit_WthoutEmail",(nameCss,ageCss,reasonCss,nameData,ageData,reasonData)=>{

    cy.get(nameCss).type(nameData)
    cy.get(ageCss).type(ageData)
    cy.get(reasonCss).type(reasonData)
    cy.get('[type="button"]').click()
})


//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
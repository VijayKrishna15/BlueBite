class BluebiteLoginPage {

    UserInfo = {

        PageTitle:'.snippet__Body-sc-12bo3rm-0.cmpVnN',

        LoginName_feild_css: '[for="input-3"]',
        LoginName_css: "#input-3",

        LoginEmail_feild_css:'[for="input-4"]',
        LoginEmail_Css:"#input-4",

        LoginAge_feild_css:'[for="input-8"]',
        LoginAge_css:'#input-8',

        LoginReason_feild_css:'[for="input-9"]',
        LoginReason_css:'#input-9'

        // cy.get('[for="input-9"]').should("have.text", Data.Validation_Age_reason)
        // cy.get("#input-9").should("be.enabled").and("have.attr", "type", "text")
    }

    getNameFeild(name) {
        cy.get(this.UserInfo.LoginName_feild_css).should("have.text", name)
    }

    getEmailFeild(email) {
        cy.get(this.UserInfo.LoginEmail_feild_css).should("have.text",email)
    }

    getAgeFeild(age){
        cy.get(this.UserInfo.LoginAge_feild_css).should("have.text",age)
    }

    getReasonFeild(reason){
        cy.get(this.UserInfo.LoginReason_feild_css).should("have.text",reason)
    }


} export default BluebiteLoginPage;